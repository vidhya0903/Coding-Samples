import UIKit

var greeting = "fdsfdjkkkk"//"Hello, playground"
//let arr = [1,1,1,1]
let arr = [1,5,7,-1]

let sum = 2
var pairs = [String]()
/*
for i in 0...arr.count-1 {
    var pairSum = arr[i]
    for j in arr.count - 1 {
        let nextarr = arr[j]
        pairSum = arr[i] + arr[j]
        if sum == pairSum {
            pairs.append("(\(arr[i])\(arr[j]))")
        }
    }
}
 */
print("The pairs--\(pairs)")

var dict : [Character: Int] = [:]
for i in greeting {
    if dict[i] == nil {
        dict[i] = 1
        print("ones\(dict)")
    }else {
        dict[i]! += 1
        print("Twos\(dict)")
    }
}
print(dict)

//Remove duplicate
  var usedCharacters = [Character]()

  for letter in greeting {
    if !usedCharacters.contains(letter) {
      usedCharacters.append(letter)
    }
  }

print(usedCharacters)

    //palindrom
for index in 0..<greeting.count/2 {
        if greeting[index] != greeting[greeting.count - 1 - index] {
            print(false)
        }
}
print(true)
